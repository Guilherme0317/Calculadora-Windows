﻿namespace CalculadoraBasica
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMult = new System.Windows.Forms.Button();
            this.BtnMais = new System.Windows.Forms.Button();
            this.BtnMenos = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnDois = new System.Windows.Forms.Button();
            this.BtnUm = new System.Windows.Forms.Button();
            this.BtnTres = new System.Windows.Forms.Button();
            this.BtnQuatro = new System.Windows.Forms.Button();
            this.BtnCinco = new System.Windows.Forms.Button();
            this.BtnSeis = new System.Windows.Forms.Button();
            this.BtnSete = new System.Windows.Forms.Button();
            this.BtnOito = new System.Windows.Forms.Button();
            this.BtnNove = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.bntCalc = new System.Windows.Forms.Button();
            this.BtnC = new System.Windows.Forms.Button();
            this.BtnPorcentagem = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BtnRaizQuadrada = new System.Windows.Forms.Button();
            this.BtnQuadrado = new System.Windows.Forms.Button();
            this.BtnReciproco = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.BtnMmenos = new System.Windows.Forms.Button();
            this.BtnMmais = new System.Windows.Forms.Button();
            this.BtnMr = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.BtnMbaixo = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.TextBox();
            this.aa = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.listBoxMemoria = new System.Windows.Forms.ListBox();
            this.BtnFecharMemoria = new System.Windows.Forms.Button();
            this.LinkLblHist = new System.Windows.Forms.LinkLabel();
            this.listBoxHist = new System.Windows.Forms.ListBox();
            this.BtnFecharHist = new System.Windows.Forms.Button();
            this.BtnLimparHist = new System.Windows.Forms.Button();
            this.LinkLabelTresBarras = new System.Windows.Forms.LinkLabel();
            this.listBoxCalcs = new System.Windows.Forms.ListBox();
            this.BtnFecharCalcs = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnMult
            // 
            this.BtnMult.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMult.Location = new System.Drawing.Point(224, 261);
            this.BtnMult.Name = "BtnMult";
            this.BtnMult.Size = new System.Drawing.Size(74, 49);
            this.BtnMult.TabIndex = 6;
            this.BtnMult.Text = "X";
            this.BtnMult.UseVisualStyleBackColor = false;
            this.BtnMult.Click += new System.EventHandler(this.BtnMult_Click);
            // 
            // BtnMais
            // 
            this.BtnMais.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMais.Location = new System.Drawing.Point(224, 353);
            this.BtnMais.Name = "BtnMais";
            this.BtnMais.Size = new System.Drawing.Size(74, 49);
            this.BtnMais.TabIndex = 4;
            this.BtnMais.Text = "+";
            this.BtnMais.UseVisualStyleBackColor = false;
            this.BtnMais.Click += new System.EventHandler(this.BtnMais_Click);
            // 
            // BtnMenos
            // 
            this.BtnMenos.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMenos.Location = new System.Drawing.Point(224, 307);
            this.BtnMenos.Name = "BtnMenos";
            this.BtnMenos.Size = new System.Drawing.Size(74, 49);
            this.BtnMenos.TabIndex = 5;
            this.BtnMenos.Text = "-";
            this.BtnMenos.UseVisualStyleBackColor = false;
            this.BtnMenos.Click += new System.EventHandler(this.BtnMenos_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDiv.Location = new System.Drawing.Point(224, 215);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(74, 49);
            this.BtnDiv.TabIndex = 7;
            this.BtnDiv.Text = "÷";
            this.BtnDiv.UseVisualStyleBackColor = false;
            this.BtnDiv.Click += new System.EventHandler(this.button4_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpar.Location = new System.Drawing.Point(151, 169);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(74, 49);
            this.BtnLimpar.TabIndex = 8;
            this.BtnLimpar.Text = "C";
            this.BtnLimpar.UseVisualStyleBackColor = false;
            this.BtnLimpar.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnDois
            // 
            this.BtnDois.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDois.Location = new System.Drawing.Point(80, 353);
            this.BtnDois.Name = "BtnDois";
            this.BtnDois.Size = new System.Drawing.Size(74, 49);
            this.BtnDois.TabIndex = 11;
            this.BtnDois.Text = "2";
            this.BtnDois.UseVisualStyleBackColor = true;
            this.BtnDois.Click += new System.EventHandler(this.BtnDois_Click);
            // 
            // BtnUm
            // 
            this.BtnUm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUm.Location = new System.Drawing.Point(7, 353);
            this.BtnUm.Name = "BtnUm";
            this.BtnUm.Size = new System.Drawing.Size(74, 49);
            this.BtnUm.TabIndex = 12;
            this.BtnUm.Text = "1";
            this.BtnUm.UseVisualStyleBackColor = true;
            this.BtnUm.Click += new System.EventHandler(this.BtnUm_Click);
            // 
            // BtnTres
            // 
            this.BtnTres.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTres.Location = new System.Drawing.Point(151, 353);
            this.BtnTres.Name = "BtnTres";
            this.BtnTres.Size = new System.Drawing.Size(74, 49);
            this.BtnTres.TabIndex = 13;
            this.BtnTres.Text = "3";
            this.BtnTres.UseVisualStyleBackColor = true;
            this.BtnTres.Click += new System.EventHandler(this.BtnTres_Click);
            // 
            // BtnQuatro
            // 
            this.BtnQuatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuatro.Location = new System.Drawing.Point(7, 307);
            this.BtnQuatro.Name = "BtnQuatro";
            this.BtnQuatro.Size = new System.Drawing.Size(74, 49);
            this.BtnQuatro.TabIndex = 14;
            this.BtnQuatro.Text = "4";
            this.BtnQuatro.UseVisualStyleBackColor = true;
            this.BtnQuatro.Click += new System.EventHandler(this.BtnQuatro_Click);
            // 
            // BtnCinco
            // 
            this.BtnCinco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCinco.Location = new System.Drawing.Point(80, 307);
            this.BtnCinco.Name = "BtnCinco";
            this.BtnCinco.Size = new System.Drawing.Size(74, 49);
            this.BtnCinco.TabIndex = 15;
            this.BtnCinco.Text = "5";
            this.BtnCinco.UseVisualStyleBackColor = true;
            this.BtnCinco.Click += new System.EventHandler(this.BtnCinco_Click);
            // 
            // BtnSeis
            // 
            this.BtnSeis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeis.Location = new System.Drawing.Point(151, 307);
            this.BtnSeis.Name = "BtnSeis";
            this.BtnSeis.Size = new System.Drawing.Size(74, 49);
            this.BtnSeis.TabIndex = 16;
            this.BtnSeis.Text = "6";
            this.BtnSeis.UseVisualStyleBackColor = true;
            this.BtnSeis.Click += new System.EventHandler(this.BtnSeis_Click);
            // 
            // BtnSete
            // 
            this.BtnSete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSete.Location = new System.Drawing.Point(7, 261);
            this.BtnSete.Name = "BtnSete";
            this.BtnSete.Size = new System.Drawing.Size(74, 49);
            this.BtnSete.TabIndex = 17;
            this.BtnSete.Text = "7";
            this.BtnSete.UseVisualStyleBackColor = true;
            this.BtnSete.Click += new System.EventHandler(this.BtnSete_Click);
            // 
            // BtnOito
            // 
            this.BtnOito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOito.Location = new System.Drawing.Point(80, 261);
            this.BtnOito.Name = "BtnOito";
            this.BtnOito.Size = new System.Drawing.Size(74, 49);
            this.BtnOito.TabIndex = 18;
            this.BtnOito.Text = "8";
            this.BtnOito.UseVisualStyleBackColor = true;
            this.BtnOito.Click += new System.EventHandler(this.BtnOito_Click);
            // 
            // BtnNove
            // 
            this.BtnNove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNove.Location = new System.Drawing.Point(151, 261);
            this.BtnNove.Name = "BtnNove";
            this.BtnNove.Size = new System.Drawing.Size(74, 49);
            this.BtnNove.TabIndex = 19;
            this.BtnNove.Text = "9";
            this.BtnNove.UseVisualStyleBackColor = true;
            this.BtnNove.Click += new System.EventHandler(this.BtnNove_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnZero.Location = new System.Drawing.Point(80, 399);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(74, 49);
            this.BtnZero.TabIndex = 20;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.BtnZero_Click);
            // 
            // bntCalc
            // 
            this.bntCalc.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bntCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntCalc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bntCalc.Location = new System.Drawing.Point(224, 399);
            this.bntCalc.Name = "bntCalc";
            this.bntCalc.Size = new System.Drawing.Size(75, 49);
            this.bntCalc.TabIndex = 21;
            this.bntCalc.Text = "=";
            this.bntCalc.UseVisualStyleBackColor = false;
            this.bntCalc.Click += new System.EventHandler(this.bntCalc_Click);
            // 
            // BtnC
            // 
            this.BtnC.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnC.Location = new System.Drawing.Point(224, 169);
            this.BtnC.Name = "BtnC";
            this.BtnC.Size = new System.Drawing.Size(74, 49);
            this.BtnC.TabIndex = 23;
            this.BtnC.Text = "⌫";
            this.BtnC.UseVisualStyleBackColor = false;
            this.BtnC.Click += new System.EventHandler(this.BtnC_Click);
            // 
            // BtnPorcentagem
            // 
            this.BtnPorcentagem.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPorcentagem.Location = new System.Drawing.Point(7, 169);
            this.BtnPorcentagem.Name = "BtnPorcentagem";
            this.BtnPorcentagem.Size = new System.Drawing.Size(74, 49);
            this.BtnPorcentagem.TabIndex = 25;
            this.BtnPorcentagem.Text = "%";
            this.BtnPorcentagem.UseVisualStyleBackColor = false;
            this.BtnPorcentagem.Click += new System.EventHandler(this.BtnPorcentagem_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(7, 399);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 49);
            this.button1.TabIndex = 26;
            this.button1.Text = "+/-";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(151, 399);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 49);
            this.button2.TabIndex = 27;
            this.button2.Text = ",";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnRaizQuadrada
            // 
            this.BtnRaizQuadrada.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnRaizQuadrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRaizQuadrada.Location = new System.Drawing.Point(151, 215);
            this.BtnRaizQuadrada.Name = "BtnRaizQuadrada";
            this.BtnRaizQuadrada.Size = new System.Drawing.Size(74, 49);
            this.BtnRaizQuadrada.TabIndex = 28;
            this.BtnRaizQuadrada.Text = "²√x";
            this.BtnRaizQuadrada.UseVisualStyleBackColor = false;
            this.BtnRaizQuadrada.Click += new System.EventHandler(this.button3_Click);
            // 
            // BtnQuadrado
            // 
            this.BtnQuadrado.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnQuadrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuadrado.Location = new System.Drawing.Point(80, 215);
            this.BtnQuadrado.Name = "BtnQuadrado";
            this.BtnQuadrado.Size = new System.Drawing.Size(74, 49);
            this.BtnQuadrado.TabIndex = 29;
            this.BtnQuadrado.Text = "x²";
            this.BtnQuadrado.UseVisualStyleBackColor = false;
            this.BtnQuadrado.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // BtnReciproco
            // 
            this.BtnReciproco.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BtnReciproco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReciproco.Location = new System.Drawing.Point(7, 215);
            this.BtnReciproco.Name = "BtnReciproco";
            this.BtnReciproco.Size = new System.Drawing.Size(74, 49);
            this.BtnReciproco.TabIndex = 30;
            this.BtnReciproco.Text = "¹/x";
            this.BtnReciproco.UseVisualStyleBackColor = false;
            this.BtnReciproco.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.MenuBar;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(80, 169);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(74, 49);
            this.button6.TabIndex = 31;
            this.button6.Text = "CE";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.Menu;
            this.button11.Location = new System.Drawing.Point(205, 127);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(44, 36);
            this.button11.TabIndex = 36;
            this.button11.Text = "MS";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // BtnMmenos
            // 
            this.BtnMmenos.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMmenos.Location = new System.Drawing.Point(155, 127);
            this.BtnMmenos.Name = "BtnMmenos";
            this.BtnMmenos.Size = new System.Drawing.Size(44, 36);
            this.BtnMmenos.TabIndex = 37;
            this.BtnMmenos.Text = "M-";
            this.BtnMmenos.UseVisualStyleBackColor = false;
            this.BtnMmenos.Click += new System.EventHandler(this.button7_Click);
            // 
            // BtnMmais
            // 
            this.BtnMmais.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMmais.Location = new System.Drawing.Point(105, 127);
            this.BtnMmais.Name = "BtnMmais";
            this.BtnMmais.Size = new System.Drawing.Size(44, 36);
            this.BtnMmais.TabIndex = 38;
            this.BtnMmais.Text = "M+";
            this.BtnMmais.UseVisualStyleBackColor = false;
            this.BtnMmais.Click += new System.EventHandler(this.button8_Click);
            // 
            // BtnMr
            // 
            this.BtnMr.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMr.Location = new System.Drawing.Point(55, 127);
            this.BtnMr.Name = "BtnMr";
            this.BtnMr.Size = new System.Drawing.Size(44, 36);
            this.BtnMr.TabIndex = 39;
            this.BtnMr.Text = "MR";
            this.BtnMr.UseVisualStyleBackColor = false;
            this.BtnMr.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Menu;
            this.button10.Location = new System.Drawing.Point(7, 127);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(44, 36);
            this.button10.TabIndex = 40;
            this.button10.Text = "MC";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // BtnMbaixo
            // 
            this.BtnMbaixo.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnMbaixo.Location = new System.Drawing.Point(255, 127);
            this.BtnMbaixo.Name = "BtnMbaixo";
            this.BtnMbaixo.Size = new System.Drawing.Size(44, 36);
            this.BtnMbaixo.TabIndex = 41;
            this.BtnMbaixo.Text = "M↓";
            this.BtnMbaixo.UseVisualStyleBackColor = false;
            this.BtnMbaixo.Click += new System.EventHandler(this.button12_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 21);
            this.label2.TabIndex = 43;
            this.label2.Text = "Padrão";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.ReadOnly = true;
            this.label1.Size = new System.Drawing.Size(291, 28);
            this.label1.TabIndex = 45;
            this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // aa
            // 
            this.aa.AutoSize = true;
            this.aa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aa.Location = new System.Drawing.Point(187, 12);
            this.aa.Name = "aa";
            this.aa.Size = new System.Drawing.Size(0, 16);
            this.aa.TabIndex = 44;
            this.aa.Click += new System.EventHandler(this.label3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(123, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 48;
            this.label3.Visible = false;
            // 
            // listBoxMemoria
            // 
            this.listBoxMemoria.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.listBoxMemoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMemoria.FormattingEnabled = true;
            this.listBoxMemoria.ItemHeight = 20;
            this.listBoxMemoria.Location = new System.Drawing.Point(320, 169);
            this.listBoxMemoria.Name = "listBoxMemoria";
            this.listBoxMemoria.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBoxMemoria.Size = new System.Drawing.Size(291, 284);
            this.listBoxMemoria.TabIndex = 49;
            this.listBoxMemoria.SelectedIndexChanged += new System.EventHandler(this.listBoxMemoria_SelectedIndexChanged);
            // 
            // BtnFecharMemoria
            // 
            this.BtnFecharMemoria.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnFecharMemoria.Location = new System.Drawing.Point(528, 183);
            this.BtnFecharMemoria.Name = "BtnFecharMemoria";
            this.BtnFecharMemoria.Size = new System.Drawing.Size(60, 35);
            this.BtnFecharMemoria.TabIndex = 50;
            this.BtnFecharMemoria.Text = "X";
            this.BtnFecharMemoria.UseVisualStyleBackColor = false;
            this.BtnFecharMemoria.Click += new System.EventHandler(this.BtnFecharListBox_Click);
            // 
            // LinkLblHist
            // 
            this.LinkLblHist.AutoSize = true;
            this.LinkLblHist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLblHist.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLblHist.LinkColor = System.Drawing.Color.Black;
            this.LinkLblHist.Location = new System.Drawing.Point(273, 11);
            this.LinkLblHist.Name = "LinkLblHist";
            this.LinkLblHist.Size = new System.Drawing.Size(25, 20);
            this.LinkLblHist.TabIndex = 51;
            this.LinkLblHist.TabStop = true;
            this.LinkLblHist.Text = "🕒";
            this.LinkLblHist.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblHist_LinkClicked);
            // 
            // listBoxHist
            // 
            this.listBoxHist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxHist.FormattingEnabled = true;
            this.listBoxHist.ItemHeight = 20;
            this.listBoxHist.Location = new System.Drawing.Point(626, 169);
            this.listBoxHist.Name = "listBoxHist";
            this.listBoxHist.Size = new System.Drawing.Size(291, 284);
            this.listBoxHist.TabIndex = 52;
            this.listBoxHist.SelectedIndexChanged += new System.EventHandler(this.listBoxHist_SelectedIndexChanged);
            // 
            // BtnFecharHist
            // 
            this.BtnFecharHist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFecharHist.Location = new System.Drawing.Point(735, 256);
            this.BtnFecharHist.Name = "BtnFecharHist";
            this.BtnFecharHist.Size = new System.Drawing.Size(60, 35);
            this.BtnFecharHist.TabIndex = 53;
            this.BtnFecharHist.Text = "X";
            this.BtnFecharHist.UseVisualStyleBackColor = true;
            this.BtnFecharHist.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // BtnLimparHist
            // 
            this.BtnLimparHist.BackColor = System.Drawing.SystemColors.Menu;
            this.BtnLimparHist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLimparHist.Location = new System.Drawing.Point(746, 177);
            this.BtnLimparHist.Name = "BtnLimparHist";
            this.BtnLimparHist.Size = new System.Drawing.Size(60, 35);
            this.BtnLimparHist.TabIndex = 54;
            this.BtnLimparHist.Text = "Limpar";
            this.BtnLimparHist.UseVisualStyleBackColor = false;
            this.BtnLimparHist.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // LinkLabelTresBarras
            // 
            this.LinkLabelTresBarras.AutoSize = true;
            this.LinkLabelTresBarras.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinkLabelTresBarras.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelTresBarras.LinkColor = System.Drawing.Color.Black;
            this.LinkLabelTresBarras.Location = new System.Drawing.Point(12, 7);
            this.LinkLabelTresBarras.Name = "LinkLabelTresBarras";
            this.LinkLabelTresBarras.Size = new System.Drawing.Size(23, 24);
            this.LinkLabelTresBarras.TabIndex = 55;
            this.LinkLabelTresBarras.TabStop = true;
            this.LinkLabelTresBarras.Text = "☰";
            this.LinkLabelTresBarras.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabelTresBarras_LinkClicked);
            // 
            // listBoxCalcs
            // 
            this.listBoxCalcs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxCalcs.FormattingEnabled = true;
            this.listBoxCalcs.ItemHeight = 18;
            this.listBoxCalcs.Location = new System.Drawing.Point(322, 35);
            this.listBoxCalcs.Name = "listBoxCalcs";
            this.listBoxCalcs.Size = new System.Drawing.Size(200, 256);
            this.listBoxCalcs.TabIndex = 56;
            // 
            // BtnFecharCalcs
            // 
            this.BtnFecharCalcs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFecharCalcs.Location = new System.Drawing.Point(469, 59);
            this.BtnFecharCalcs.Name = "BtnFecharCalcs";
            this.BtnFecharCalcs.Size = new System.Drawing.Size(40, 24);
            this.BtnFecharCalcs.TabIndex = 57;
            this.BtnFecharCalcs.Text = "X";
            this.BtnFecharCalcs.UseVisualStyleBackColor = true;
            this.BtnFecharCalcs.Click += new System.EventHandler(this.button3_Click_3);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 35);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1.Size = new System.Drawing.Size(291, 23);
            this.textBox1.TabIndex = 58;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ClientSize = new System.Drawing.Size(304, 466);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.BtnFecharCalcs);
            this.Controls.Add(this.listBoxCalcs);
            this.Controls.Add(this.LinkLabelTresBarras);
            this.Controls.Add(this.BtnLimparHist);
            this.Controls.Add(this.BtnFecharHist);
            this.Controls.Add(this.listBoxHist);
            this.Controls.Add(this.LinkLblHist);
            this.Controls.Add(this.BtnFecharMemoria);
            this.Controls.Add(this.listBoxMemoria);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.aa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnMbaixo);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.BtnMr);
            this.Controls.Add(this.BtnMmais);
            this.Controls.Add(this.BtnMmenos);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.BtnReciproco);
            this.Controls.Add(this.BtnQuadrado);
            this.Controls.Add(this.BtnRaizQuadrada);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnPorcentagem);
            this.Controls.Add(this.BtnC);
            this.Controls.Add(this.bntCalc);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.BtnNove);
            this.Controls.Add(this.BtnOito);
            this.Controls.Add(this.BtnSete);
            this.Controls.Add(this.BtnSeis);
            this.Controls.Add(this.BtnCinco);
            this.Controls.Add(this.BtnQuatro);
            this.Controls.Add(this.BtnTres);
            this.Controls.Add(this.BtnUm);
            this.Controls.Add(this.BtnDois);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.BtnMenos);
            this.Controls.Add(this.BtnMais);
            this.Controls.Add(this.BtnMult);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnMult;
        private System.Windows.Forms.Button BtnMais;
        private System.Windows.Forms.Button BtnMenos;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnDois;
        private System.Windows.Forms.Button BtnUm;
        private System.Windows.Forms.Button BtnTres;
        private System.Windows.Forms.Button BtnQuatro;
        private System.Windows.Forms.Button BtnCinco;
        private System.Windows.Forms.Button BtnSeis;
        private System.Windows.Forms.Button BtnSete;
        private System.Windows.Forms.Button BtnOito;
        private System.Windows.Forms.Button BtnNove;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.Button bntCalc;
        private System.Windows.Forms.Button BtnC;
        private System.Windows.Forms.Button BtnPorcentagem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BtnRaizQuadrada;
        private System.Windows.Forms.Button BtnQuadrado;
        private System.Windows.Forms.Button BtnReciproco;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button BtnMmenos;
        private System.Windows.Forms.Button BtnMmais;
        private System.Windows.Forms.Button BtnMr;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button BtnMbaixo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox label1;
        private System.Windows.Forms.Label aa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBoxMemoria;
        private System.Windows.Forms.Button BtnFecharMemoria;
        private System.Windows.Forms.LinkLabel LinkLblHist;
        private System.Windows.Forms.ListBox listBoxHist;
        private System.Windows.Forms.Button BtnFecharHist;
        private System.Windows.Forms.Button BtnLimparHist;
        private System.Windows.Forms.LinkLabel LinkLabelTresBarras;
        private System.Windows.Forms.ListBox listBoxCalcs;
        private System.Windows.Forms.Button BtnFecharCalcs;
        private System.Windows.Forms.TextBox textBox1;
    }
}

